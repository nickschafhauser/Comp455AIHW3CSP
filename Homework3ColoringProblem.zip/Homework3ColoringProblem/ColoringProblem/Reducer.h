#ifndef REDUCER_H
#define REDUCER_H

#include "ConnectionMap.h"

bool backtrack(ConnectionMap& m, int assign);

#endif